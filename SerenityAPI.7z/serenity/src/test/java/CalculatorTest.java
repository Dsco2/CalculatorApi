import net.serenitybdd.junit.runners.SerenityRunner;
import net.serenitybdd.rest.SerenityRest;
import org.junit.Test;
import org.junit.runner.RunWith;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.interactions.Get;
import static org.assertj.core.api.Assertions.assertThat;


@RunWith(SerenityRunner.class)
public class CalculatorTest {

    private final String restApiUrl = "http://localhost:5000";

    @Test
    public void calculatorTest(){
        Actor david = Actor.named("David prueba Serenity")
                .whoCan(CallAnApi.at(restApiUrl));

        david.attemptsTo(
                Get.resource("/Calculator/GetHistory")
        );

        assertThat(SerenityRest.lastResponse().statusCode()).isEqualTo(200);

    }
}